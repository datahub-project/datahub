#!/bin/bash
# Port forwarding script for local development
chmod 600 share_key.pem

if [ -z "$1" ]; then
    echo "Usage: ./port_forward.sh LOCAL_PORT:REMOTE_PORT"
    echo ""
    echo "Examples:"
    echo "  ./port_forward.sh 3000:3000    # Forward local 3000 to remote 3000"
    echo "  ./port_forward.sh 3005:3000    # Forward local 3005 to remote 3000"
    echo "  ./port_forward.sh 9002:9002    # Forward local 9002 to remote 9002 (DataHub)"
    echo ""
    echo "Common use cases:"
    echo "  - Frontend dev server (yarn start): 3000:3000"
    echo "  - DataHub UI: 9002:9002"
    exit 1
fi

# Parse LOCAL_PORT:REMOTE_PORT
PORT_MAPPING="$1"

if [[ ! "$PORT_MAPPING" =~ ^[0-9]+:[0-9]+$ ]]; then
    echo "❌ Invalid format. Use LOCAL_PORT:REMOTE_PORT (e.g., 3000:3000)"
    exit 1
fi

LOCAL_PORT=$(echo "$PORT_MAPPING" | cut -d: -f1)
REMOTE_PORT=$(echo "$PORT_MAPPING" | cut -d: -f2)

echo "🔗 Setting up port forwarding..."
echo "   Local:  http://localhost:$LOCAL_PORT"
echo "   Remote: $REMOTE_PORT on 54.214.204.15"
echo ""
echo "Keep this terminal open. Press Ctrl+C to stop."
echo ""

ssh -i share_key.pem -L $LOCAL_PORT:localhost:$REMOTE_PORT ec2-user@54.214.204.15
