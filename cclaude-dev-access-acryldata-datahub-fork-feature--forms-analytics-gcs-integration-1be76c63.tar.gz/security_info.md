# Security Information

## Share Key Details
- **Share Key Name**: 1be76c63-share-20251030-115018
- **Expires**: 2025-11-06 11:50:18
- **Expires In**: 168 hours from creation
- **Session**: acryldata/datahub-fork/feature--forms-analytics-gcs-integration (1be76c63)

## Security Warnings
⚠️ **IMPORTANT**: This is a time-limited share key with the following restrictions:

1. **Automatic Expiration**: This key will automatically expire and be removed from the instance
2. **Session-Specific**: This key only works for this specific session
3. **Do Not Share Further**: Do not share this key with additional people
4. **Limited Scope**: This key cannot access other sessions or resources

## Manual Revocation
If you need to revoke access immediately, use the provided `revoke_access.sh` script or run:

```bash
ssh -i share_key.pem ec2-user@54.214.204.15 'sed -i /cclaude-share-1be76c63-share-20251030-115018/d ~/.ssh/authorized_keys'
```

## Emergency Contact
For security issues or questions, contact: developer@company.com

## Audit Trail
All share key activities are logged for security auditing purposes.
