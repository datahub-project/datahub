# IntelliJ Remote Development Setup

## Method 1: CLI Connection (Recommended)
If you have IntelliJ IDEA CLI tools installed, you can connect directly:

```bash
# Make sure SSH key has correct permissions
chmod 600 cclaude-dev-shirshankadas.pem

# Connect using IntelliJ CLI with SSH URL
idea ssh://ec2-user@54.214.204.15:22/workspace/acryldata/datahub-fork
```

Or use the provided script: `./connect_intellij.sh`

## Method 2: GUI Setup
1. Open IntelliJ IDEA
2. Go to File → Remote Development → SSH
3. Click "+" to add new connection
4. Configure connection settings:
   - Host: cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63-
   - Username: ec2-user
   - Port: 22
   - Authentication: Key pair
   - Private key: ~/.cclaude/share_key.pem
   - Project path: /workspace/acryldata/datahub-fork

## Method 3: SSH Config Setup
1. Copy the SSH config from `intellij_ssh_config` to your `~/.ssh/config` file
2. Ensure you have the SSH key in the correct location: `~/.cclaude/share_key.pem`
3. Make sure the key has correct permissions: `chmod 600 ~/.cclaude/share_key.pem`
4. In IntelliJ, use "cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63-" as the host

## Installing IntelliJ CLI Tools
If you don't have the `idea` command available:

### macOS
```bash
# Add to your shell profile (~/.zshrc or ~/.bash_profile)
export PATH="/Applications/IntelliJ IDEA.app/Contents/MacOS:$PATH"
```

### Linux
```bash
# Usually available after installation, or create a symlink
sudo ln -s /opt/idea/bin/idea.sh /usr/local/bin/idea
```

### Windows
```bash
# Add IntelliJ's bin directory to your PATH
# Usually: C:\Program Files\JetBrains\IntelliJ IDEA <version>\bin
```

## Notes
- IntelliJ will install JetBrains Gateway automatically on the remote server
- The initial connection may take a few minutes to set up the remote environment
- All your IntelliJ plugins and settings will be synchronized to the remote session
- CLI method is fastest for quick connections to existing projects
