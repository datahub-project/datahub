#!/bin/bash
# Manual revocation script for share key
echo "Revoking access for share key: 1be76c63-share-20251030-115018"
echo "This will immediately remove the share key from the instance."

read -p "Are you sure you want to revoke access? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    chmod 600 share_key.pem
    ssh -i share_key.pem ec2-user@54.214.204.15 'sed -i /cclaude-share-1be76c63-share-20251030-115018/d ~/.ssh/authorized_keys'
    echo "✅ Access revoked successfully"
    echo "The share key has been removed from the instance."
else
    echo "❌ Revocation cancelled"
fi
