#!/bin/bash
# Connect to IntelliJ IDEA via GUI remote development
chmod 600 share_key.pem

HOST_NAME="cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63-"

echo "Setting up IntelliJ IDEA remote development..."
echo "Project path: /workspace/acryldata/datahub-fork"
echo "Host: $HOST_NAME"

# Check if SSH is set up
if ! ssh -q -o ConnectTimeout=5 -o BatchMode=yes "$HOST_NAME" "echo 'test'" &>/dev/null; then
    echo "⚠️  SSH not configured for $HOST_NAME"
    echo "Running setup..."
    ./setup_ssh.sh

    if [ $? -ne 0 ]; then
        echo "❌ SSH setup failed"
        exit 1
    fi
fi

echo "✅ SSH configuration ready!"
echo ""

# Check if idea command is available for launching IntelliJ
if command -v idea &> /dev/null; then
    echo "🚀 Launching IntelliJ IDEA..."
    idea &
    sleep 2
else
    echo "📱 Please launch IntelliJ IDEA manually"
fi

echo ""
echo "📋 IntelliJ Remote Development Setup Instructions:"
echo "   1. IntelliJ IDEA should now be open (or open it manually)"
echo "   2. From the Welcome screen, click 'Remote Development'"
echo "   3. Select 'SSH Connection'"
echo "   4. Click 'New Connection' and enter:"
echo "      • Host: 54.214.204.15"
echo "      • Username: ec2-user"
echo "      • Port: 22"
echo "      • Authentication: Key pair"
echo "      • Private key: $(pwd)/cclaude-dev-shirshankadas.pem"
echo "   5. Click 'Check Connection and Continue'"
echo "   6. Select project directory: /workspace/acryldata/datahub-fork"
echo "   7. Choose your IntelliJ IDEA version and click 'Start IDE and Connect'"
echo ""
echo "💡 Alternative: Use the SSH host alias '$HOST_NAME' instead of IP"
echo ""
echo "📝 For direct SSH access: ssh $HOST_NAME"
