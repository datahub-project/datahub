#!/bin/bash
# Connect to VSCode via CLI
chmod 600 share_key.pem

HOST_NAME="cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63-"

echo "Connecting to VSCode..."
echo "Project path: /workspace/acryldata/datahub-fork"
echo "Host: $HOST_NAME"

# Check if code command is available
if ! command -v code &> /dev/null; then
    echo "❌ 'code' command not found in PATH"
    echo ""
    echo "📋 To install VSCode CLI tools:"
    echo "   1. Open VSCode"
    echo "   2. Press Cmd+Shift+P (Mac) or Ctrl+Shift+P (Windows/Linux)"
    echo "   3. Type 'Shell Command: Install code command in PATH'"
    echo "   4. Select it and press Enter"
    echo "   5. Restart your terminal"
    echo ""
    echo "💡 If you cannot install the 'code' command, use:"
    echo "   ./remote_terminal.sh"
    exit 1
fi

# Check if SSH is set up
if ! ssh -q -o ConnectTimeout=5 -o BatchMode=yes "$HOST_NAME" "echo 'test'" &>/dev/null; then
    echo "⚠️  SSH not configured for $HOST_NAME"
    echo "Running setup..."
    ./setup_ssh.sh

    if [ $? -ne 0 ]; then
        echo "❌ SSH setup failed"
        exit 1
    fi
fi

echo "✅ Launching VSCode..."
code --remote ssh-remote+$HOST_NAME /workspace/acryldata/datahub-fork
