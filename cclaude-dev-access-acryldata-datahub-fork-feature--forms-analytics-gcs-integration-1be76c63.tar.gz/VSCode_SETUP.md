# VSCode Remote Development Setup

## Method 1: CLI Connection (Recommended)
If you have VSCode CLI tools installed, use the provided script:

```bash
./connect_vscode.sh
```

This will automatically connect to the remote project using VSCode's Remote-SSH extension.

## Method 2: Manual Setup
1. Install the "Remote - SSH" extension in VSCode
2. Copy the SSH config from `vscode_ssh_config` to your `~/.ssh/config` file
3. Ensure you have the SSH key in the correct location: `~/.cclaude/share_key.pem`
4. Make sure the key has correct permissions: `chmod 600 ~/.cclaude/share_key.pem`

### Connecting Manually
1. Open VSCode
2. Press `Cmd+Shift+P` (Mac) or `Ctrl+Shift+P` (Windows/Linux)
3. Type "Remote-SSH: Connect to Host"
4. Select "cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63-"
5. Choose "Linux" as the platform
6. Open folder: `/workspace/acryldata/datahub-fork`

### Command Line Alternative
```bash
code --remote ssh-remote+cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63- /workspace/acryldata/datahub-fork
```

## Installing VSCode CLI
If you don't have the `code` command available:

### macOS/Linux
VSCode CLI is usually installed automatically. If not:
1. Open VSCode
2. Press `Cmd+Shift+P` (Mac) or `Ctrl+Shift+P` (Linux)
3. Type "Shell Command: Install 'code' command in PATH"

### Windows
The `code` command is available in Command Prompt/PowerShell after VSCode installation.
