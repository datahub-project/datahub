# 🚀 CClaude Developer Session Access

## 📋 Session Details
- **Repository**: acryldata/datahub-fork
- **Instance**: 54.214.204.15
- **Created**: 2025-10-14 15:58:56

## 🔒 Security Information
- **Share Key**: 1be76c63-share-20251030-115018
- **Expires**: 2025-11-06 11:50:18 (168 hours)
- **Security Warning**: This is a time-limited share key. It will automatically expire.
- **Do NOT share this key further** - it's specific to this session.

## 🚀 Connect to Remote Environment

**Pick your connection method:**

### 📝 VSCode
```bash
./connect_vscode.sh
```
Open in VSCode with Remote-SSH extension.

### 🎯 Cursor
```bash
./connect_cursor.sh
```
Open in Cursor with Remote-SSH extension.

### 💻 Remote Terminal
```bash
./remote_terminal.sh
```
Persistent tmux session - reconnects if you run it again. Your work stays alive even if you disconnect.

### ☕ IntelliJ IDEA (Beta)
```bash
./connect_intellij.sh
```
Follow the on-screen instructions for IntelliJ remote development.
*Requires IntelliJ Ultimate with SSH Gateway*

### ⚡ Plain SSH (For Quick Checks)
```bash
./ssh_direct.sh
```
Direct SSH access without tmux. Useful for quick inspections or one-off commands.

## 📁 Working Directory
`/workspace/acryldata/datahub-fork`

## 🌐 DataHub UI Access
Available at: http://54.214.204.15:9002

**If not available:**
1. Check if DataHub is already running on the remote instance - use ssh / remote terminal to login and check if DataHub is running via docker quickstart
2. If not - run it with `./gradlew quickstartDebug` (like you normally do on your local machine)
3. After DataHub starts up normally - you will be able to view it with the link above

## 🎨 Frontend Development (Hot Reload)

For frontend development with hot reload:

1. Start the dev server on the remote instance:
   ```bash
   ./remote_terminal.sh
   cd datahub-web-react
   yarn start  # Runs on port 3000
   ```

2. In a separate terminal on your local machine, forward the port:
   ```bash
   ./port_forward.sh 3000:3000
   ```
   Or use a different local port:
   ```bash
   ./port_forward.sh 3005:3000
   ```

3. Open http://localhost:3000 (or 3005) in your browser
   - Hot reload will work automatically
   - Changes on the remote instance reflect immediately

## 🛡️ Revoke Access
To revoke this access immediately:
```bash
./revoke_access.sh
```

