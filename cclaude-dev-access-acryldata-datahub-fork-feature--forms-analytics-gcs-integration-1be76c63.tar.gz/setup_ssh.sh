#!/bin/bash
# Setup SSH config for cclaude session
chmod 600 share_key.pem

HOST_NAME="cclaude-acryldata-datahub-fork-feature--forms-analytics-gcs-integration--1be76c63-"
IP_ADDRESS="54.214.204.15"
KEY_FILE="$(pwd)/share_key.pem"

echo "🔧 Setting up SSH config for VSCode/IntelliJ..."
echo "Host: $HOST_NAME"
echo "IP: $IP_ADDRESS"
echo ""

# Create ~/.ssh directory if it doesn't exist
mkdir -p ~/.ssh
touch ~/.ssh/config

# Check if config already exists
if grep -q "Host $HOST_NAME" ~/.ssh/config; then
    echo "✅ SSH config already exists for $HOST_NAME"

    # Test the connection
    echo "🧪 Testing SSH connection..."
    if ssh -q -o ConnectTimeout=5 -o BatchMode=yes "$HOST_NAME" "echo 'Connection test successful'" 2>/dev/null; then
        echo "✅ SSH connection works!"
        echo "Ready to use: code --remote ssh-remote+$HOST_NAME /path"
        exit 0
    else
        echo "⚠️  SSH config exists but connection failed. Updating config..."
    fi
fi

# Add or update SSH config
echo "📝 Adding SSH configuration to ~/.ssh/config..."

# Remove any existing entry for this host
if grep -q "Host $HOST_NAME" ~/.ssh/config; then
    # Create backup
    cp ~/.ssh/config ~/.ssh/config.bak.$(date +%s)
    # Remove existing entry
    sed -i.tmp "/Host $HOST_NAME/,/^$/d" ~/.ssh/config
    rm -f ~/.ssh/config.tmp
fi

# Add new entry
cat >> ~/.ssh/config <<EOF

# cclaude session: acryldata/datahub-fork/feature--forms-analytics-gcs-integration (1be76c63)
Host $HOST_NAME
    HostName $IP_ADDRESS
    User ec2-user
    Port 22
    IdentityFile $KEY_FILE
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    ServerAliveInterval 60
    ServerAliveCountMax 3
EOF

echo "✅ SSH config added!"

# Test the connection
echo "🧪 Testing SSH connection..."
if ssh -q -o ConnectTimeout=10 -o BatchMode=yes "$HOST_NAME" "echo 'SSH setup successful!'" 2>/dev/null; then
    echo "✅ SSH connection works!"
    echo ""
    echo "🎉 Setup complete! You can now use:"
    echo "   VSCode: code --remote ssh-remote+$HOST_NAME /workspace/acryldata/datahub-fork"
    echo "   SSH:    ssh $HOST_NAME"
    echo ""
else
    echo "❌ SSH connection failed. Please check:"
    echo "   1. Instance is running: 54.214.204.15"
    echo "   2. Key file exists: $KEY_FILE"
    echo "   3. Key permissions: $(ls -la $KEY_FILE 2>/dev/null || echo 'KEY NOT FOUND')"
    exit 1
fi
