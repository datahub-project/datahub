#!/bin/bash
# Connect with remote terminal
chmod 600 share_key.pem

# Use local username for stable session name (unique per developer, persistent across runs)
LOCAL_USER="$USER"
SESSION_NAME="dev-terminal-$LOCAL_USER"

echo "🚀 Connecting to remote terminal session: $SESSION_NAME"
echo "   (Creating new session or attaching to existing one)"

# Try to attach to existing session first, otherwise create new one
ssh -i share_key.pem ec2-user@54.214.204.15 -t "cd /workspace/acryldata/datahub-fork && (tmux attach-session -t '$SESSION_NAME' 2>/dev/null || tmux new-session -s '$SESSION_NAME')"
