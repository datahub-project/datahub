#!/bin/bash
# Connect to existing Claude Code session
chmod 600 share_key.pem
ssh -i share_key.pem ec2-user@54.214.204.15 -t "tmux attach-session -t 'cclaude-feature--forms-analytics-gcs-integration-1be76c63'"
