#!/bin/bash
# Direct SSH access
chmod 600 share_key.pem
ssh -i share_key.pem ec2-user@54.214.204.15
